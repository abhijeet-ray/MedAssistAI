"""
MedAssist RAG Lambda - Using Google Gemini API
Uses Gemini 1.5 Flash with direct DynamoDB text retrieval
"""
import json
import os
import requests
from datetime import datetime
import boto3

# AWS clients
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

# Environment variables
DOCUMENT_TABLE = os.environ.get('DOCUMENT_TABLE', 'MedAssist-Documents')
GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY', 'AIzaSyB4Uv2HoAaQVTRN5-KrcXPpf60lLbatj1s')

# CORS headers for all responses
CORS_HEADERS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET'
}


def get_document_text(session_id):
    """
    Retrieve document text from DynamoDB for the given session.
    Uses query with sessionId as partition key.
    """
    try:
        table = dynamodb.Table(DOCUMENT_TABLE)
        
        # Query for documents with this sessionId as PK
        response = table.query(
            KeyConditionExpression='PK = :sid',
            ExpressionAttributeValues={':sid': session_id}
        )
        
        items = response.get('Items', [])
        
        if not items:
            print(f"No documents found for session {session_id}")
            return ""
        
        # Concatenate all document text
        all_text = []
        for item in items:
            # Use 'documentText' field from schema
            text = item.get('documentText', '')
            if text:
                all_text.append(text[:5000])  # Max 5000 chars per doc
        
        combined = " ".join(all_text)
        print(f"Retrieved {len(items)} documents, total text length: {len(combined)}")
        
        if not combined:
            print(f"WARNING: Documents found but no text extracted")
        
        return combined
        
    except Exception as e:
        print(f"Error retrieving documents: {str(e)}")
        import traceback
        traceback.print_exc()
        return ""


def call_gemini(prompt):
    """
    Call Google Gemini API to generate response.
    """
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key={GEMINI_API_KEY}"
        
        payload = {
            "contents": [{
                "parts": [{
                    "text": prompt
                }]
            }]
        }
        
        print(f"Calling Gemini API with prompt length: {len(prompt)}")
        
        response = requests.post(url, json=payload, timeout=30)
        
        if response.status_code != 200:
            print(f"Gemini API error: {response.status_code} - {response.text}")
            return f"Error calling Gemini API: {response.status_code}"
        
        data = response.json()
        
        # Extract answer from Gemini response
        answer = data["candidates"][0]["content"]["parts"][0]["text"]
        
        print(f"Gemini response length: {len(answer)}")
        
        return answer
        
    except requests.exceptions.Timeout:
        print("Gemini API timeout")
        return "Request timed out. Please try again."
    
    except KeyError as e:
        print(f"Error parsing Gemini response: {str(e)}")
        print(f"Response data: {json.dumps(data) if 'data' in locals() else 'No data'}")
        return "Error parsing AI response. Please try again."
    
    except Exception as e:
        print(f"Error calling Gemini: {str(e)}")
        import traceback
        traceback.print_exc()
        return f"Error generating response: {str(e)}"


def get_role_explanation_style(role):
    """
    Get explanation style based on user role.
    """
    role_styles = {
        'doctor': 'clinical medical explanation for healthcare professionals with technical terminology',
        'patient': 'simple easy language for patients without medical jargon',
        'asha': 'community health worker explanation for rural healthcare guidance with practical advice'
    }
    return role_styles.get(role, role_styles['patient'])


def format_chat_history(chat_history):
    """
    Format chat history for the prompt.
    """
    if not chat_history or len(chat_history) == 0:
        return "No previous conversation."
    
    formatted = []
    for entry in chat_history:
        user_msg = entry.get('user', '')
        ai_msg = entry.get('ai', '')
        if user_msg and ai_msg:
            formatted.append(f"User: {user_msg}\nAI: {ai_msg}")
    
    return "\n\n".join(formatted) if formatted else "No previous conversation."


def handler(event, context):
    """
    Lambda handler for chat requests with conversational memory and role-based responses.
    """
    print(f"Event: {json.dumps(event)}")
    
    # Handle OPTIONS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': ''
        }
    
    try:
        # Parse request
        body = json.loads(event.get('body', '{}'))
        session_id = body.get('sessionId')
        question = body.get('message')
        role = body.get('role', 'patient')
        chat_history = body.get('chatHistory', [])
        
        print(f"Session: {session_id}, Question: {question}, Role: {role}, History length: {len(chat_history)}")
        
        if not session_id or not question:
            return {
                'statusCode': 400,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'error': 'Missing sessionId or message'
                })
            }
        
        # Step 1: Get document text from DynamoDB
        document_text = get_document_text(session_id)
        
        # Step 2: Check if we have document text (removed "Document not processed yet" message)
        if not document_text:
            return {
                'statusCode': 200,
                'headers': CORS_HEADERS,
                'body': json.dumps({
                    'answer': 'Please upload a medical document to get started with your health analysis.',
                    'source': 'none',
                    'timestamp': datetime.utcnow().isoformat(),
                    'chatHistory': chat_history
                })
            }
        
        # Step 3: Get role-based explanation style
        explanation_style = get_role_explanation_style(role)
        
        # Step 4: Format chat history
        formatted_history = format_chat_history(chat_history)
        
        # Step 5: Create conversational prompt for Gemini
        prompt = f"""You are a medical AI assistant.

Medical report:
{document_text}

Conversation history:
{formatted_history}

User question: {question}

Instructions:
- Explain using {explanation_style}
- Do NOT repeat information already provided in the conversation history
- Answer ONLY the user's new question
- Be concise and direct
- Use bullet points when listing multiple items
- If the question was already answered, provide additional details or a different perspective

Respond now:"""
        
        print(f"Prompt length: {len(prompt)}")
        
        # Step 6: Call Gemini
        answer = call_gemini(prompt)
        
        print(f"Answer length: {len(answer)}")
        
        # Step 7: Update chat history
        updated_history = chat_history.copy()
        updated_history.append({
            'user': question,
            'ai': answer
        })
        
        # Keep only last 10 exchanges to avoid token limits
        if len(updated_history) > 10:
            updated_history = updated_history[-10:]
        
        # Step 8: Return response with updated history
        return {
            'statusCode': 200,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'answer': answer,
                'source': 'uploaded_document',
                'timestamp': datetime.utcnow().isoformat(),
                'chatHistory': updated_history
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            'statusCode': 500,
            'headers': CORS_HEADERS,
            'body': json.dumps({
                'error': f'Internal error: {str(e)}',
                'timestamp': datetime.utcnow().isoformat()
            })
        }
